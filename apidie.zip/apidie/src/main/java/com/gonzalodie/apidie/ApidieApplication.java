package com.gonzalodie.apidie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApidieApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApidieApplication.class, args);
	}

}
