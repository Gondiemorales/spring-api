package com.gonzalodie.apidie;


import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class LoginController {

    private HashMap<String, String> usuarios = new HashMap<>();

    @GetMapping("/usuarios")
    public ResponseEntity<HashMap<String, String>> getUsuarios(){
        
        return new ResponseEntity<HashMap<String, String>>(usuarios, HttpStatus.OK);
    }


    @PostMapping("/usuarios")
    public ResponseEntity<Usuario> postTasks(@RequestBody Usuario u){

        if(usuarios.containsKey(u)){
            return new ResponseEntity<Usuario>(u,  HttpStatus.BAD_REQUEST);
        }
        else{
            usuarios.put(u.getNombre(), u.getContraseña());

            return new ResponseEntity<Usuario>(u, HttpStatus.OK);
        }
        


    }

   
    
     


}



