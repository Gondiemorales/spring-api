package com.gonzalodie.apidie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApidieApplicationTests {

	@Test
	void contextLoads() {
	}

}
